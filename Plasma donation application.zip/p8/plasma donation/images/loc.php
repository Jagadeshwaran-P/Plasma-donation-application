
<html><head>
<script type="text/javascript">
    function showPosition(){
        if(navigator.geolocation){
            navigator.geolocation.getCurrentPosition(function(position){
                var Latitude= position.coords.latitude; 
				var Longitude=  position.coords.longitude;
                document.getElementById("lat").value=Latitude;
				document.getElementById("lng").value =Longitude;
           			});
        } else{
            alert("Sorry, your browser does not support HTML5 geolocation.");
        }
    }
</script>
</head>
<body>
 <form name="form1" method="post" action="">
	     <table width="100%" border="0">
        <tr>
          <th scope="col"><button type="button" onClick="showPosition();">Show Position</button></th>
          <th scope="col"><div align="left">
            <input name="lat" type="text" id="lat">
          </div></th>
          <th scope="col">&nbsp;</th>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><input name="lng" type="text" id="lng"></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><input name="btn" type="submit" value="Address"></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>
	  </form>
	  </body>
	  </html>