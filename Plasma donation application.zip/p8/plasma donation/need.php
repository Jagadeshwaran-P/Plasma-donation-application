<?php
include("dbconnect.php");
session_start();
extract($_POST);
$uid=$_SESSION['uname'];


$bg=$_REQUEST['bg'];
$did=$_REQUEST['did'];
$mobile=$_REQUEST['phone'];

$max_qry = mysqli_query($conn,"select max(id) from booking");
	$max_row = mysqli_fetch_array($max_qry); 
	$id=$max_row['max(id)']+1;
	$qry=mysqli_query($conn,"insert into booking values('$id','$uid','$did','0')");
	if($qry)
	{
	
	$msg=$bg." Blood Group  "." Needed ";
	
	
	
		?>
		 <iframe src="http://smsserver9.creativepoint.in/api.php?username=fantasy&password=596692&to=<?php echo $mobile;?>&from=FSSMSS&message=Dear User your msg is <?php echo $msg;?> Sent By FSMSG FSSMSS&PEID=1501563800000030506&templateid=1507162882948811640"style="display:send sucess" class="iframe"></iframe>
		
		<?php
	
	
	
	?>
<script language="javascript">
	alert("Sent Successfully..");
	window.location.href="user.php";
	</script>
	<?php
	}
	else
	{
	?>
<script language="javascript">
	alert("UnSuccessfully..");
	window.location.href="user.php";
	</script>
	<?php
	}
	
?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style>

.i{

display:none;}
</style>
</head>

<body>
</body>
</html>
