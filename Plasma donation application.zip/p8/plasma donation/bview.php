<?php
include("dbconnect.php");
session_start();
extract($_POST);
$did=$_SESSION['did'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Blood Bank</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link href="css/animate.min.css" rel="stylesheet"> 
	<link href="css/animate.css" rel="stylesheet" />
	<link href="css/prettyPhoto.css" rel="stylesheet"> 
  <link href="css/style.css" rel="stylesheet">
	
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
<!--
.style1 {	font-size: 24px;
	font-weight: bold;
}
.style2 {	font-size: 18px;
	font-weight: bold;
}
-->
    </style>
</head>
<body>
<form id="form1" name="form1" method="post" action="">
	<nav class="navbar navbar-default navbar-fixed-top">
		<div class="container">
			<div class="row">
				<div class="col-md-2">
					<div class="site-logo">
							<a href="index.php" class="brand">Plasma Donation</a>		</div>
				</div>					  

				<div class="col-md-10">	 
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#menu">
							<i class="fa fa-bars"></i>						</button>
					</div>
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse" id="menu">
						<ul class="nav navbar-nav navbar-right">
							 <li><a href="donor.php">Home</a></li>
							  <li><a href="bview.php">View User Details</a></li>
							  <li><a href="donorlog.php">LogOut</a></li>	
							  
						</ul>
					</div>
					<!-- /.Navbar-collapse -->		 
				</div>
			</div>
		</div>		
	</nav>
	<!--/#about-->
	<!--/#portfolio-item-->
	<section id="contact">
	  <div class="contact-page">
	    <p>&nbsp;</p>
	    <p>&nbsp;</p>
	    <p>&nbsp;</p>
	  </div>
		<!--/#contact-page-->		
	</section>
	
    <p><!--/#footer-->
      
      
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="js/jquery.js"></script>
    </p>
    <p align="center"><span class="style1">Welcome To Donor Page </span></p>
    <p>&nbsp;</p>
    <p align="right">&nbsp;</p>
    <p>&nbsp;</p>
     <p>&nbsp;</p>
    <p align="center">&nbsp;</p>
    <p><span class="style1">User  Details </span></p>
    <p align="center">&nbsp;</p>
    <table width="90%" border="1" align="center">
      <tr>
        <td width="11%" height="49" bgcolor="#CCCCFF"><div align="center" class="style2">Sl.No</div></td>
        <td width="18%" bgcolor="#CCCCFF"><div align="center" class="style2">User Name </div></td>
        <td width="18%" bgcolor="#CCCCFF"><div align="center" class="style2">Phone Number </div></td>
		<td width="18%" bgcolor="#CCCCFF"><div align="center" class="style2">Email </div></td>
        <td width="22%" bgcolor="#CCCCFF"><div align="center" class="style2">Status</div></td>
      </tr>
      <?php
	$i=1;
	$qry=mysqli_query($conn,"select * from booking where did='$did' && status='1'");
	while($row=mysqli_fetch_array($qry))
	{
	$uid=$row['uid'];
	$qrt=mysqli_query($conn,"select * from register1 where id='$uid'");
	$r1=mysqli_fetch_array($qrt);
	?>
      <tr>
        <td height="56"><div align="center"><?php echo $i;?></div></td>
        <td><div align="center"><?php echo $r1['name'];?></div></td>
             <td><div align="center"><?php echo $r1['pnumber'];?></div></td>
			  <td><div align="center"><?php echo $r1['email'];?></div></td>
        <td><div align="center"><?php echo "Accepted";?></td>
      </tr>
      <?php
	$i++;
	}
	
	

	
	


	?> 
    </table>
    <p align="center">&nbsp;</p>
    <p align="center">&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>
    <p><span class="style1"><img src="images/donate.png" width="399" height="374" /></span></p>
    <p align="center">&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.prettyPhoto.js"></script>
        <script src="js/jquery.isotope.min.js"></script> 
        <script src="js/wow.min.js"></script>
        <script src="js/jquery.easing.min.js"></script>	
        <script src="js/main.js"></script>
  </p>
	  <footer id="footer" class="midnight-blue">
	   <div class="container">
            <div class="row">
              <div class="col-md-6 col-md-offset-3">
				  <div class="text-center">
					  <a href="#home" class="scrollup"><i class="fa fa-angle-up fa-3x"></i></a>					</div>
                  &copy; 2015 <a target="_blank" href="http://bootstraptaste.com/" title="Free Twitter Bootstrap WordPress Themes and HTML templates">bootstraptaste</a>. All Rights Reserved.
                  <!-- 
                        All links in the footer should remain intact. 
                        Licenseing information is available at: http://bootstraptaste.com/license/
                        You can buy this theme without footer links online at: http://bootstraptaste.com/buy/?theme=OnePage
                    -->
              </div></form>
</body>
</html>